import type { OrderItem } from '../types'
import { fmt } from '../data'

interface Props {
  orders: OrderItem[]
  onBack: () => void
}

export default function PaymentScreen({ orders, onBack }: Props) {
  const subtotal = orders.reduce((s, i) => s + i.dish.price * i.qty, 0)
  const vat = Math.round(subtotal * 0.08)
  const total = subtotal + vat

  const promos = [
    { code: 'MADAME10', label: 'Giảm 10% cho khách mới', value: Math.round(total * 0.1) },
    { code: 'BIRTHDAY', label: 'Ưu đãi sinh nhật', value: 50000 },
  ]

  return (
    <div style={{ minHeight: '100vh', background: '#f7f2ea', fontFamily: "'Be Vietnam Pro', sans-serif" }}>

      {/* Header */}
      <div style={{
        background: '#fff', borderBottom: '1px solid rgba(200,160,80,0.2)',
        boxShadow: '0 1px 12px rgba(0,0,0,0.07)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', height: 56, padding: '0 16px' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '8px 8px 8px 0', display: 'flex', alignItems: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 18, color: '#1e0f04' }}>Thanh toán</div>
          </div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: 'rgba(200,130,30,0.1)', border: '1px solid rgba(200,130,30,0.3)', borderRadius: 16, padding: '3px 10px' }}>
            <span style={{ fontSize: 11.5, color: '#8a5010', fontWeight: 700 }}>Bàn A1</span>
          </div>
        </div>
      </div>

      <div style={{ padding: '16px', paddingBottom: 140 }}>

        {/* Payment methods */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>Phương thức thanh toán</div>
          {[
            { icon: '💳', label: 'Thẻ ngân hàng / Quẹt thẻ', sub: 'Visa, Mastercard, JCB' },
            { icon: '📱', label: 'Ví điện tử', sub: 'MoMo, ZaloPay, VNPay' },
            { icon: '💵', label: 'Tiền mặt', sub: 'Thanh toán khi nhận hóa đơn' },
          ].map((m, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              background: '#fff', borderRadius: 12, padding: '13px 14px',
              marginBottom: 8, border: i === 0 ? '2px solid #f0c040' : '1px solid rgba(200,160,80,0.2)',
              boxShadow: i === 0 ? '0 3px 16px rgba(240,192,64,0.2)' : '0 2px 8px rgba(0,0,0,0.06)',
              cursor: 'pointer',
            }}>
              <span style={{ fontSize: 24 }}>{m.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: '#1e0f04', marginBottom: 2 }}>{m.label}</div>
                <div style={{ fontSize: 12, color: '#a08060' }}>{m.sub}</div>
              </div>
              {i === 0 && (
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'linear-gradient(135deg, #c9a227, #f0c040)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Promo codes */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 10 }}>Mã khuyến mãi</div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <input placeholder="Nhập mã giảm giá..." style={{
              flex: 1, padding: '11px 14px',
              border: '1.5px solid #e8d5a0', borderRadius: 10,
              fontSize: 13, fontFamily: "'Be Vietnam Pro', sans-serif",
              color: '#1e0f04', background: '#fffbf0', outline: 'none',
            }}/>
            <button style={{
              padding: '11px 16px', background: 'linear-gradient(135deg, #c9a227, #f0c040)',
              border: 'none', borderRadius: 10, fontWeight: 700, fontSize: 13,
              color: '#1e0f04', cursor: 'pointer',
            }}>Áp dụng</button>
          </div>
          {promos.map(p => (
            <div key={p.code} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              background: '#fffbf0', border: '1px dashed #e8d5a0', borderRadius: 10,
              padding: '10px 12px', marginBottom: 6,
            }}>
              <div>
                <span style={{ fontSize: 12, fontWeight: 700, color: '#b8860b', background: '#fef3c7', padding: '2px 8px', borderRadius: 6, marginRight: 8 }}>{p.code}</span>
                <span style={{ fontSize: 12, color: '#7a5030' }}>{p.label}</span>
              </div>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#16a34a' }}>-{fmt(p.value)}</span>
            </div>
          ))}
        </div>

        {/* Bill */}
        <div style={{
          background: '#fff', borderRadius: 14, padding: '14px 16px',
          border: '1px solid rgba(200,160,80,0.15)',
          boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
        }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 16, color: '#1e0f04', marginBottom: 12, paddingBottom: 10, borderBottom: '1px solid rgba(200,160,80,0.2)' }}>
            Hoá đơn
          </div>
          {orders.map((item, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 13, color: '#5a3010' }}>{item.dish.name} <span style={{ color: '#a08060' }}>×{item.qty}</span></span>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(item.dish.price * item.qty)}</span>
            </div>
          ))}
          <div style={{ paddingTop: 10, marginTop: 4, borderTop: '1px dashed rgba(200,160,80,0.3)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 13, color: '#7a5030' }}>Tạm tính</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(subtotal)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 13, color: '#7a5030' }}>VAT (8%)</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(vat)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 8, borderTop: '2px solid rgba(200,160,80,0.2)' }}>
              <span style={{ fontSize: 15, fontWeight: 800, color: '#1e0f04' }}>Tổng cộng</span>
              <span style={{ fontSize: 20, fontWeight: 800, color: '#b82c0a', fontFamily: "'Playfair Display', serif" }}>{fmt(total)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{
        position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100,
        background: '#fff', borderTop: '1px solid rgba(200,160,80,0.2)',
        boxShadow: '0 -4px 24px rgba(0,0,0,0.1)',
        padding: '14px 16px 28px',
      }}>
        <div style={{ maxWidth: 430, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <span style={{ fontSize: 13, color: '#7a5030' }}>Tổng thanh toán:</span>
            <span style={{ fontSize: 20, fontWeight: 800, color: '#b82c0a', fontFamily: "'Playfair Display', serif" }}>{fmt(total)}</span>
          </div>
          <button style={{
            width: '100%', padding: '16px',
            background: 'linear-gradient(135deg, #b8860b 0%, #d4a820 30%, #f0c040 60%, #d4a820 100%)',
            border: 'none', borderRadius: 14, fontSize: 16, fontWeight: 800,
            fontFamily: "'Be Vietnam Pro', sans-serif", color: '#1e0f04', cursor: 'pointer',
            letterSpacing: '0.1em', boxShadow: '0 6px 28px rgba(212,168,32,0.5)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
            </svg>
            XÁC NHẬN THANH TOÁN
          </button>
        </div>
      </div>
    </div>
  )
}
