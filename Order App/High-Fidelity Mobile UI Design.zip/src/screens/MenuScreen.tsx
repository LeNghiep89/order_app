import { useState } from 'react'
import { ALL_DISHES, CATEGORIES, fmt } from '../data'
import type { Dish, CartItem } from '../types'

// ─── Item Detail Bottom Sheet ─────────────────────────────────────────────────

function ItemDetail({ dish, onClose, onAdd }: { dish: Dish; onClose: () => void; onAdd: (item: CartItem) => void }) {
  const [qty, setQty] = useState(1)
  const [selected, setSelected] = useState<string[]>([])

  const toggle = (m: string) =>
    setSelected(s => s.includes(m) ? s.filter(x => x !== m) : [...s, m])

  return (
    <div
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, zIndex: 300, background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}
    >
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', maxWidth: 430,
        background: '#fff', borderRadius: '22px 22px 0 0',
        overflow: 'hidden', boxShadow: '0 -16px 60px rgba(0,0,0,0.4)',
        maxHeight: '90vh', overflowY: 'auto',
      }}>
        {/* Photo */}
        <div style={{ position: 'relative', height: 200, background: '#3d2010' }}>
          <img src={dish.image} alt={dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.45) 100%)' }}/>
          <button onClick={onClose} style={{
            position: 'absolute', top: 14, right: 14,
            width: 32, height: 32, borderRadius: '50%',
            background: 'rgba(0,0,0,0.45)', border: 'none',
            color: '#fff', fontSize: 20, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1,
          }}>×</button>
          {dish.originalPrice && (
            <div style={{
              position: 'absolute', top: 14, left: 14,
              background: 'linear-gradient(135deg, #d63031, #e84393)',
              color: '#fff', fontSize: 11, fontWeight: 700,
              padding: '3px 8px', borderRadius: 6,
            }}>
              -{Math.round((1 - dish.price / dish.originalPrice) * 100)}%
            </div>
          )}
        </div>

        <div style={{ padding: '20px 20px 0' }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 22, color: '#1e0f04', marginBottom: 6 }}>
            {dish.name}
          </div>
          <div style={{ fontSize: 13, color: '#7a5030', lineHeight: 1.6, marginBottom: 16 }}>{dish.desc}</div>

          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 20 }}>
            <span style={{ fontSize: 22, fontWeight: 700, color: '#b82c0a' }}>{fmt(dish.price)}</span>
            {dish.originalPrice && (
              <span style={{ fontSize: 14, color: '#a08060', textDecoration: 'line-through' }}>{fmt(dish.originalPrice)}</span>
            )}
          </div>

          {/* Modifiers */}
          {dish.modifiers && dish.modifiers.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#6b4020', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
                Tuỳ chọn
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {dish.modifiers.map(m => {
                  const on = selected.includes(m)
                  return (
                    <button key={m} onClick={() => toggle(m)} style={{
                      padding: '6px 14px', borderRadius: 20,
                      border: on ? '1.5px solid #f0c040' : '1.5px solid #e0cca0',
                      background: on ? 'linear-gradient(135deg, #c9a227, #f0c040)' : '#fffbf0',
                      color: on ? '#1e0f04' : '#8a6040',
                      fontSize: 13, fontWeight: on ? 700 : 400,
                      cursor: 'pointer', fontFamily: "'Be Vietnam Pro', sans-serif",
                      transition: 'all 0.15s',
                    }}>{m}</button>
                  )
                })}
              </div>
            </div>
          )}

          {/* Qty + Add */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, paddingBottom: 28 }}>
            <div style={{
              display: 'flex', alignItems: 'center',
              border: '2px solid #e8d5a0', borderRadius: 12, overflow: 'hidden',
              background: '#fffbf0',
            }}>
              <button onClick={() => setQty(Math.max(1, qty - 1))} style={{
                width: 44, height: 44, border: 'none',
                background: qty <= 1 ? '#f5ead5' : 'linear-gradient(135deg, #e8d590, #f0c040)',
                cursor: qty <= 1 ? 'default' : 'pointer',
                fontSize: 20, color: qty <= 1 ? '#c8b880' : '#1e0f04',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>−</button>
              <div style={{ width: 44, textAlign: 'center', fontSize: 18, fontWeight: 700, color: '#1e0f04', fontFamily: "'Playfair Display', serif" }}>{qty}</div>
              <button onClick={() => setQty(qty + 1)} style={{
                width: 44, height: 44, border: 'none',
                background: 'linear-gradient(135deg, #c9a227, #f0c040)',
                cursor: 'pointer', fontSize: 20, color: '#1e0f04',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>+</button>
            </div>
            <button
              onClick={() => { onAdd({ dish, qty, selectedModifiers: selected }); onClose() }}
              style={{
                flex: 1, padding: '14px',
                background: 'linear-gradient(135deg, #b8860b 0%, #f0c040 100%)',
                border: 'none', borderRadius: 12,
                fontSize: 14, fontWeight: 800,
                fontFamily: "'Be Vietnam Pro', sans-serif",
                color: '#1e0f04', cursor: 'pointer',
                letterSpacing: '0.06em',
                boxShadow: '0 4px 20px rgba(240,192,64,0.4)',
              }}
            >
              THÊM MÓN — {fmt(dish.price * qty)}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Menu Screen ──────────────────────────────────────────────────────────────

interface Props {
  cart: CartItem[]
  onAddToCart: (item: CartItem) => void
  onViewCart: () => void
  guests: number
}

export default function MenuScreen({ cart, onAddToCart, onViewCart, guests }: Props) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('Tất cả')
  const [detail, setDetail] = useState<Dish | null>(null)

  const cartCount = cart.reduce((s, i) => s + i.qty, 0)
  const cartTotal = cart.reduce((s, i) => s + i.dish.price * i.qty, 0)

  const filtered = ALL_DISHES.filter(d => {
    const matchCat = category === 'Tất cả' || d.category === category
    const matchSearch = !search || d.name.toLowerCase().includes(search.toLowerCase())
    return matchCat && matchSearch
  })

  const grouped: Record<string, Dish[]> = {}
  filtered.forEach(d => {
    if (!grouped[d.category]) grouped[d.category] = []
    grouped[d.category].push(d)
  })

  return (
    <div style={{ position: 'relative', minHeight: '100vh', background: '#fdf8f0' }}>

      {/* Top nav */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: 'linear-gradient(135deg, #1a0a02 0%, #2e1508 100%)',
        borderBottom: '1px solid rgba(240,192,64,0.3)',
        boxShadow: '0 2px 20px rgba(0,0,0,0.4)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px 8px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, #c9a227, #f0c040)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(240,192,64,0.4)', flexShrink: 0 }}>
              <span style={{ fontSize: 16 }}>🌸</span>
            </div>
            <div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontWeight: 600, fontSize: 18, color: '#f0c040', lineHeight: 1.1, letterSpacing: '0.02em' }}>
                Madame Lân
              </div>
              <div style={{ fontSize: 10, color: 'rgba(240,192,64,0.55)', letterSpacing: '0.15em', textTransform: 'uppercase', fontWeight: 500 }}>
                Nhà hàng truyền thống
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: 'rgba(240,192,64,0.12)', border: '1px solid rgba(240,192,64,0.35)', borderRadius: 20, padding: '4px 10px' }}>
              <span style={{ fontSize: 11, color: 'rgba(240,192,64,0.8)', fontWeight: 600, letterSpacing: '0.06em' }}>Bàn A1</span>
            </div>
            <div style={{ fontSize: 11, color: 'rgba(240,192,64,0.4)' }}>{guests} khách</div>
          </div>
        </div>

        {/* Search */}
        <div style={{ padding: '0 14px 10px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(255,245,220,0.08)', border: '1px solid rgba(240,192,64,0.22)', borderRadius: 10, padding: '8px 12px' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(240,192,64,0.5)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Tìm món ăn..." style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'rgba(253,243,227,0.88)', fontSize: 13, fontFamily: "'Be Vietnam Pro', sans-serif" }}/>
          </div>
        </div>

        {/* Categories */}
        <div className="hide-scrollbar" style={{ overflowX: 'auto', padding: '0 12px 10px', display: 'flex', gap: 7, whiteSpace: 'nowrap' }}>
          {CATEGORIES.map(cat => {
            const active = category === cat
            return (
              <button key={cat} onClick={() => setCategory(cat)} style={{
                display: 'inline-flex', alignItems: 'center', padding: '5px 13px', borderRadius: 20,
                border: active ? '1.5px solid #f0c040' : '1.5px solid rgba(240,192,64,0.22)',
                background: active ? 'linear-gradient(135deg, #c9a227, #f0c040)' : 'rgba(255,245,220,0.06)',
                color: active ? '#1e0f04' : 'rgba(253,243,227,0.7)',
                fontSize: 12.5, fontWeight: active ? 700 : 500,
                fontFamily: "'Be Vietnam Pro', sans-serif", cursor: 'pointer', flexShrink: 0,
              }}>{cat}</button>
            )
          })}
        </div>
      </div>

      {/* Featured */}
      {category === 'Tất cả' && !search && (
        <div style={{ padding: '14px 16px 6px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <div style={{ width: 3, height: 15, borderRadius: 2, background: 'linear-gradient(180deg, #f0c040, #c9a227)' }}/>
            <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.18em', color: '#b8860b', textTransform: 'uppercase' }}>Món nổi bật</span>
          </div>
          <div className="hide-scrollbar" style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 4 }}>
            {ALL_DISHES.filter(d => d.originalPrice).slice(0, 3).map(dish => (
              <button key={dish.id} onClick={() => setDetail(dish)} style={{
                minWidth: 200, borderRadius: 14, overflow: 'hidden',
                background: '#fff', boxShadow: '0 4px 20px rgba(0,0,0,0.12)',
                border: '1px solid rgba(200,160,80,0.15)', cursor: 'pointer', textAlign: 'left',
                flexShrink: 0, padding: 0,
              }}>
                <div style={{ height: 110, background: '#3d2010', position: 'relative', overflow: 'hidden' }}>
                  <img src={dish.image} alt={dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
                  <div style={{ position: 'absolute', top: 8, left: 8, background: 'linear-gradient(135deg, #d63031, #e84393)', color: '#fff', fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 5 }}>
                    -{Math.round((1 - dish.price / dish.originalPrice!) * 100)}%
                  </div>
                </div>
                <div style={{ padding: '8px 10px 10px' }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: 13, color: '#1e0f04', marginBottom: 3 }}>{dish.name}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: '#b82c0a' }}>{fmt(dish.price)}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Dish list */}
      <div style={{ padding: '8px 16px', paddingBottom: cartCount > 0 ? 100 : 32 }}>
        {Object.entries(grouped).map(([cat, dishes]) => (
          <div key={cat}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10, marginTop: 6 }}>
              <div style={{ width: 3, height: 13, borderRadius: 2, background: 'linear-gradient(180deg, #f0c040, #c9a227)' }}/>
              <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.17em', color: '#b8860b', textTransform: 'uppercase' }}>{cat}</span>
            </div>
            {dishes.map(dish => (
              <button key={dish.id} onClick={() => setDetail(dish)} style={{
                display: 'flex', gap: 12, width: '100%', textAlign: 'left',
                background: '#fff', borderRadius: 13, padding: '11px',
                marginBottom: 9, border: '1px solid rgba(200,160,80,0.15)',
                boxShadow: '0 2px 12px rgba(0,0,0,0.07)', cursor: 'pointer',
                alignItems: 'center',
              }}>
                <div style={{ width: 72, height: 72, borderRadius: 9, overflow: 'hidden', flexShrink: 0, background: '#4a2810' }}>
                  <img src={dish.image} alt={dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: 14, color: '#1e0f04', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{dish.name}</div>
                  <div style={{ fontSize: 11, color: '#7a5030', lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', marginBottom: 5 }}>{dish.desc}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    {dish.originalPrice && <span style={{ fontSize: 11, color: '#a08060', textDecoration: 'line-through' }}>{fmt(dish.originalPrice)}</span>}
                    <span style={{ fontSize: 14, fontWeight: 700, color: '#b82c0a' }}>{fmt(dish.price)}</span>
                  </div>
                </div>
                <div style={{
                  width: 34, height: 34, borderRadius: '50%',
                  background: 'linear-gradient(135deg, #e8b830, #f0c040)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 22, color: '#1e0f04', flexShrink: 0,
                  boxShadow: '0 2px 8px rgba(240,192,64,0.4)',
                }}>+</div>
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* Cart bar */}
      {cartCount > 0 && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100, padding: '10px 16px 28px', background: 'linear-gradient(180deg, transparent, rgba(253,248,240,0.95) 30%)' }}>
          <button onClick={onViewCart} style={{
            width: '100%', maxWidth: 430, margin: '0 auto', display: 'flex',
            alignItems: 'center', justifyContent: 'space-between',
            background: 'linear-gradient(135deg, #d4a820, #f0c040 50%, #d4a820)',
            border: 'none', borderRadius: 14, padding: '14px 18px',
            boxShadow: '0 6px 28px rgba(240,192,64,0.45)',
            cursor: 'pointer', fontFamily: "'Be Vietnam Pro', sans-serif",
          }}>
            <div style={{ background: 'rgba(30,15,4,0.18)', borderRadius: 8, padding: '3px 10px', fontSize: 13, fontWeight: 700, color: '#1e0f04' }}>
              {cartCount} món
            </div>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#1e0f04', letterSpacing: '0.04em' }}>XEM MÓN ĐÃ GỌI</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#1e0f04' }}>{fmt(cartTotal)}</div>
          </button>
        </div>
      )}

      {detail && (
        <ItemDetail dish={detail} onClose={() => setDetail(null)} onAdd={item => { onAddToCart(item); setDetail(null) }} />
      )}
    </div>
  )
}
