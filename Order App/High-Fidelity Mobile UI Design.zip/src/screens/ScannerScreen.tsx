import { useState, useEffect, useRef } from 'react'

// ─── Stylised QR dots ─────────────────────────────────────────────────────────

function QRGraphic() {
  const cells: [number, number][] = [
    [0,0],[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[0,1],[6,1],
    [0,2],[2,2],[3,2],[4,2],[6,2],[0,3],[2,3],[4,3],[6,3],
    [0,4],[2,4],[3,4],[4,4],[6,4],[0,5],[6,5],
    [0,6],[1,6],[2,6],[3,6],[4,6],[5,6],[6,6],
    [14,0],[15,0],[16,0],[17,0],[18,0],[19,0],[20,0],[14,1],[20,1],
    [14,2],[16,2],[17,2],[18,2],[20,2],[14,3],[16,3],[18,3],[20,3],
    [14,4],[16,4],[17,4],[18,4],[20,4],[14,5],[20,5],
    [14,6],[15,6],[16,6],[17,6],[18,6],[19,6],[20,6],
    [0,14],[1,14],[2,14],[3,14],[4,14],[5,14],[6,14],[0,15],[6,15],
    [0,16],[2,16],[3,16],[4,16],[6,16],[0,17],[2,17],[4,17],[6,17],
    [0,18],[2,18],[3,18],[4,18],[6,18],[0,19],[6,19],
    [0,20],[1,20],[2,20],[3,20],[4,20],[5,20],[6,20],
    [8,0],[10,0],[12,0],[9,2],[11,2],[13,2],[8,4],[10,4],[12,4],
    [7,8],[9,8],[11,8],[13,8],[15,8],[17,8],[19,8],
    [8,10],[10,10],[12,10],[14,10],[16,10],[18,10],[20,10],
    [8,12],[9,12],[11,12],[13,12],[15,12],[17,12],[19,12],
    [8,14],[10,14],[12,14],[9,16],[11,16],[13,16],
    [8,18],[10,18],[12,18],[15,14],[17,14],[19,14],[16,16],[18,16],[20,16],
    [15,18],[17,18],[19,18],[16,20],[18,20],[20,20],
  ]
  const s = 21, c = 8.5
  return (
    <svg viewBox={`0 0 ${s * c} ${s * c}`} width={s * c} height={s * c} style={{ display: 'block' }}>
      {cells.map(([col, row], i) => (
        <rect key={i} x={col * c + 1} y={row * c + 1} width={c - 1.5} height={c - 1.5} rx={1.5} fill="rgba(30,15,4,0.9)" />
      ))}
    </svg>
  )
}

function ScanLine({ success }: { success: boolean }) {
  const [pos, setPos] = useState(0)
  const dirRef = useRef(1)
  const posRef = useRef(0)
  const rafRef = useRef(0)

  useEffect(() => {
    if (success) return
    const run = () => {
      posRef.current += dirRef.current * 1.4
      if (posRef.current >= 100) { posRef.current = 100; dirRef.current = -1 }
      if (posRef.current <= 0) { posRef.current = 0; dirRef.current = 1 }
      setPos(posRef.current)
      rafRef.current = requestAnimationFrame(run)
    }
    rafRef.current = requestAnimationFrame(run)
    return () => cancelAnimationFrame(rafRef.current)
  }, [success])

  return (
    <div style={{
      position: 'absolute', left: 0, right: 0,
      top: `${pos}%`, height: 2,
      background: success
        ? 'rgba(40,200,100,0.9)'
        : 'linear-gradient(90deg, transparent, rgba(240,192,64,0.95) 20%, #f0c040 50%, rgba(240,192,64,0.95) 80%, transparent)',
      boxShadow: success ? '0 0 12px 3px rgba(40,200,100,0.6)' : '0 0 8px 2px rgba(240,192,64,0.5)',
      transition: 'background 0.3s, box-shadow 0.3s',
      zIndex: 10,
    }}/>
  )
}

interface Props {
  onSuccess: () => void
  onManual: () => void
}

export default function ScannerScreen({ onSuccess, onManual }: Props) {
  const [success, setSuccess] = useState(false)
  const [showError, setShowError] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => {
      setSuccess(true)
      setTimeout(onSuccess, 700)
    }, 3200)
    return () => clearTimeout(t)
  }, [onSuccess])

  const gold = success ? '#22c55e' : '#f0c040'
  const glow = success
    ? '0 0 16px rgba(34,197,94,0.8)'
    : '0 0 10px rgba(240,192,64,0.6)'

  return (
    <div style={{ position: 'relative', width: '100%', height: '100vh', overflow: 'hidden', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <img
        src="https://images.unsplash.com/photo-1685904899685-058c71a8f4e3?w=800&h=1400&fit=crop&auto=format"
        alt="Restaurant interior"
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(3px) brightness(0.35) saturate(1.1)', transform: 'scale(1.05)' }}
      />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(15,6,2,0.7) 0%, rgba(35,15,4,0.45) 45%, rgba(15,6,2,0.75) 100%)' }}/>

      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 430, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', padding: '0 24px' }}>

        {/* Header */}
        <div style={{ paddingTop: 56, display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 36 }}>
          <div style={{
            width: 54, height: 54, borderRadius: '50%',
            background: 'linear-gradient(135deg, #b8860b 0%, #f0c040 50%, #c9a227 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 20px rgba(240,192,64,0.35)', marginBottom: 10,
          }}>
            <span style={{ fontSize: 26 }}>🌸</span>
          </div>
          <div style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontWeight: 700, fontSize: 24, color: '#f0c040', letterSpacing: '0.03em' }}>
            Madame Lân
          </div>
          <div style={{ fontSize: 10, color: 'rgba(240,192,64,0.5)', letterSpacing: '0.22em', textTransform: 'uppercase', marginTop: 3, fontWeight: 500 }}>
            Nhà hàng truyền thống
          </div>
        </div>

        {/* Error banner */}
        {showError && (
          <div style={{
            width: '100%', background: 'rgba(185,28,28,0.88)',
            border: '1px solid rgba(255,100,80,0.4)', borderRadius: 10,
            padding: '10px 14px', display: 'flex', gap: 8, marginBottom: 16, backdropFilter: 'blur(8px)',
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fca5a5" strokeWidth="2.5" strokeLinecap="round" style={{ flexShrink: 0, marginTop: 1 }}>
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#fca5a5', marginBottom: 1 }}>Không thể quét mã</div>
              <div style={{ fontSize: 11, color: 'rgba(254,205,195,0.85)', lineHeight: 1.5 }}>
                Mã QR không hợp lệ hoặc bạn đang ở ngoài phạm vi nhà hàng
              </div>
            </div>
            <button onClick={() => setShowError(false)} style={{ background: 'none', border: 'none', color: 'rgba(255,200,190,0.6)', cursor: 'pointer', fontSize: 18, lineHeight: 1, padding: 0 }}>×</button>
          </div>
        )}

        {/* Viewfinder */}
        <div style={{ position: 'relative', width: 244, height: 244, marginBottom: 32 }}>
          {/* Success flash overlay */}
          {success && (
            <div style={{
              position: 'absolute', inset: 0, zIndex: 20, borderRadius: 12,
              background: 'rgba(34,197,94,0.18)',
              animation: 'pulse 0.6s ease-out',
            }}/>
          )}
          <div style={{
            position: 'absolute', inset: 0, background: 'rgba(255,248,228,0.97)',
            borderRadius: 12, overflow: 'hidden',
            boxShadow: success
              ? `0 0 0 4px rgba(34,197,94,0.8), 0 16px 48px rgba(0,0,0,0.5)`
              : `0 12px 48px rgba(0,0,0,0.5)`,
            transition: 'box-shadow 0.4s',
          }}>
            <ScanLine success={success} />
            <div style={{ padding: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
              <QRGraphic />
            </div>
          </div>
          {/* Corner brackets */}
          {[
            { top: -10, left: -10, bt: true, bl: true, btr: 5, bbr: 0, brl: 0, brr: 0 },
            { top: -10, right: -10, bt: true, br: true, btr: 0, bbr: 0, brl: 5, brr: 0 },
            { bottom: -10, left: -10, bb: true, bl: true, btr: 0, bbr: 5, brl: 0, brr: 0 },
            { bottom: -10, right: -10, bb: true, br: true, btr: 0, bbr: 0, brl: 0, brr: 5 },
          ].map((c, i) => (
            <div key={i} style={{
              position: 'absolute', width: 30, height: 30,
              top: c.top, bottom: c.bottom, left: c.left, right: c.right,
              borderTop: c.bt ? `3.5px solid ${gold}` : undefined,
              borderBottom: c.bb ? `3.5px solid ${gold}` : undefined,
              borderLeft: c.bl ? `3.5px solid ${gold}` : undefined,
              borderRight: c.br ? `3.5px solid ${gold}` : undefined,
              borderTopLeftRadius: c.btr, borderTopRightRadius: c.brl,
              borderBottomLeftRadius: c.bbr, borderBottomRightRadius: c.brr,
              boxShadow: glow, transition: 'border-color 0.4s, box-shadow 0.4s',
            }}/>
          ))}
        </div>

        {/* Status text */}
        <div style={{ textAlign: 'center', marginBottom: 'auto' }}>
          {success ? (
            <>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 8 }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                <span style={{ fontSize: 17, fontWeight: 700, color: '#22c55e' }}>Quét thành công!</span>
              </div>
              <div style={{ fontSize: 13, color: 'rgba(255,245,215,0.6)' }}>Đang chuyển đến bàn của bạn...</div>
            </>
          ) : (
            <>
              <div style={{ fontSize: 16, fontWeight: 600, color: 'rgba(255,245,215,0.95)', lineHeight: 1.55, marginBottom: 8 }}>
                Quét mã QR tại bàn để bắt đầu đặt món
              </div>
              <div style={{ fontSize: 13, color: 'rgba(240,192,64,0.6)', lineHeight: 1.6, maxWidth: 280 }}>
                Nhiều khách hàng có thể cùng quét để gọi món chung
              </div>
            </>
          )}
        </div>

        {/* Bottom */}
        {!success && (
          <div style={{ width: '100%', paddingBottom: 44, marginTop: 44 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: 'rgba(240,192,64,0.18)' }}/>
              <span style={{ fontSize: 11, color: 'rgba(240,192,64,0.38)', letterSpacing: '0.1em' }}>HOẶC</span>
              <div style={{ flex: 1, height: 1, background: 'rgba(240,192,64,0.18)' }}/>
            </div>
            <button
              onClick={onManual}
              style={{
                width: '100%', padding: '14px',
                background: 'transparent',
                border: '1.5px solid rgba(240,192,64,0.4)',
                borderRadius: 12, color: 'rgba(240,192,64,0.8)',
                fontSize: 14, fontWeight: 600,
                fontFamily: "'Be Vietnam Pro', sans-serif",
                cursor: 'pointer', letterSpacing: '0.02em',
                backdropFilter: 'blur(4px)',
              }}
            >
              Nhập mã bàn thủ công
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
