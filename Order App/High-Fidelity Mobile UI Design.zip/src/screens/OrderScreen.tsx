import type { OrderItem, OrderStatus } from '../types'
import { fmt } from '../data'

const STATUS_CONFIG: Record<OrderStatus, { label: string; bg: string; color: string; dot: string }> = {
  sent:      { label: 'Đã gửi',        bg: '#f3f4f6', color: '#6b7280', dot: '#9ca3af' },
  preparing: { label: 'Đang chuẩn bị', bg: '#fffbeb', color: '#d97706', dot: '#f59e0b' },
  served:    { label: 'Đã phục vụ',    bg: '#f0fdf4', color: '#16a34a', dot: '#22c55e' },
}

function StatusBadge({ status }: { status: OrderStatus }) {
  const c = STATUS_CONFIG[status]
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      background: c.bg, borderRadius: 20,
      padding: '5px 10px',
      border: `1px solid ${c.dot}33`,
    }}>
      <div style={{ width: 7, height: 7, borderRadius: '50%', background: c.dot, boxShadow: `0 0 4px ${c.dot}` }}/>
      <span style={{ fontSize: 11.5, fontWeight: 700, color: c.color, whiteSpace: 'nowrap', letterSpacing: '0.02em' }}>{c.label}</span>
    </div>
  )
}

interface Props {
  orders: OrderItem[]
  onPayment: () => void
  onBack: () => void
  submittedAt: Date
}

export default function OrderScreen({ orders, onPayment, onBack, submittedAt }: Props) {
  const subtotal = orders.reduce((s, i) => s + i.dish.price * i.qty, 0)
  const vat = Math.round(subtotal * 0.08)
  const total = subtotal + vat

  const ts = submittedAt.toLocaleString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).replace(',', '')

  const sentCount = orders.filter(o => o.status === 'sent').length
  const prepCount = orders.filter(o => o.status === 'preparing').length
  const servedCount = orders.filter(o => o.status === 'served').length

  return (
    <div style={{ minHeight: '100vh', background: '#f7f2ea', fontFamily: "'Be Vietnam Pro', sans-serif" }}>

      {/* Header */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: '#fff', borderBottom: '1px solid rgba(200,160,80,0.2)',
        boxShadow: '0 1px 12px rgba(0,0,0,0.07)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', height: 56, padding: '0 16px' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '8px 8px 8px 0', display: 'flex', alignItems: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 17, color: '#1e0f04', lineHeight: 1.2 }}>Món ăn đã gọi</div>
          </div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 5,
            background: 'rgba(200,130,30,0.1)', border: '1px solid rgba(200,130,30,0.3)',
            borderRadius: 16, padding: '3px 10px',
          }}>
            <span style={{ fontSize: 11.5, color: '#8a5010', fontWeight: 700 }}>Bàn A1</span>
          </div>
        </div>

        {/* Order info bar */}
        <div style={{ padding: '0 16px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8a6040" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
            </svg>
            <span style={{ fontSize: 12, color: '#8a6040' }}>Gọi lúc: <strong style={{ color: '#5a3010' }}>{ts}</strong></span>
          </div>
          <div style={{ display: 'flex', gap: 5 }}>
            {sentCount > 0 && <span style={{ fontSize: 11, background: '#f3f4f6', color: '#6b7280', padding: '2px 8px', borderRadius: 10, fontWeight: 600 }}>{sentCount} chờ</span>}
            {prepCount > 0 && <span style={{ fontSize: 11, background: '#fffbeb', color: '#d97706', padding: '2px 8px', borderRadius: 10, fontWeight: 600 }}>{prepCount} nấu</span>}
            {servedCount > 0 && <span style={{ fontSize: 11, background: '#f0fdf4', color: '#16a34a', padding: '2px 8px', borderRadius: 10, fontWeight: 600 }}>{servedCount} xong</span>}
          </div>
        </div>
      </div>

      <div style={{ padding: '14px 16px', paddingBottom: 130 }}>

        {/* Progress tracker */}
        <div style={{
          background: '#fff', borderRadius: 14, padding: '14px 16px', marginBottom: 14,
          border: '1px solid rgba(200,160,80,0.15)', boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
            Tiến độ phục vụ
          </div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            {(['sent', 'preparing', 'served'] as OrderStatus[]).map((s, i) => {
              const c = STATUS_CONFIG[s]
              const counts = [sentCount, prepCount, servedCount]
              const active = counts[i] > 0
              return (
                <div key={s} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>
                  {i > 0 && (
                    <div style={{ position: 'absolute', left: '-50%', right: '50%', top: 14, height: 2, background: active ? c.dot : '#e5e7eb', transition: 'background 0.3s' }}/>
                  )}
                  <div style={{
                    width: 28, height: 28, borderRadius: '50%',
                    background: active ? c.dot : '#e5e7eb',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    marginBottom: 5, zIndex: 1, transition: 'background 0.3s',
                    boxShadow: active ? `0 0 8px ${c.dot}66` : 'none',
                  }}>
                    {s === 'sent' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={active ? '#fff' : '#9ca3af'} strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>}
                    {s === 'preparing' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={active ? '#fff' : '#9ca3af'} strokeWidth="2.5" strokeLinecap="round"><path d="M12 2a10 10 0 1 0 10 10"/></svg>}
                    {s === 'served' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={active ? '#fff' : '#9ca3af'} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                  </div>
                  <span style={{ fontSize: 10, color: active ? c.color : '#9ca3af', fontWeight: active ? 700 : 400, textAlign: 'center', lineHeight: 1.3 }}>
                    {c.label}
                  </span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Order items */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          <div style={{ width: 3, height: 14, borderRadius: 2, background: 'linear-gradient(180deg, #f0c040, #c9a227)' }}/>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Chi tiết đơn gọi
          </span>
        </div>

        {orders.map((item, i) => (
          <div key={i} style={{
            background: '#fff', borderRadius: 14, marginBottom: 9,
            border: '1px solid rgba(200,160,80,0.15)',
            boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
            overflow: 'hidden',
          }}>
            {/* Status color strip */}
            <div style={{ height: 3, background: STATUS_CONFIG[item.status].dot, opacity: 0.6 }}/>
            <div style={{ display: 'flex', gap: 12, padding: '12px 12px' }}>
              <div style={{ width: 64, height: 64, borderRadius: 8, overflow: 'hidden', flexShrink: 0, background: '#4a2810' }}>
                <img src={item.dish.image} alt={item.dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8, marginBottom: 5 }}>
                  <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: 13.5, color: '#1e0f04', lineHeight: 1.25, flex: 1, minWidth: 0 }}>
                    {item.dish.name}
                  </div>
                  <StatusBadge status={item.status} />
                </div>
                {item.selectedModifiers.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 6 }}>
                    {item.selectedModifiers.map(m => (
                      <span key={m} style={{ fontSize: 10.5, color: '#8a5c20', background: '#fff8e8', border: '1px solid #e8d5a0', borderRadius: 9, padding: '1px 7px', fontWeight: 500 }}>{m}</span>
                    ))}
                  </div>
                )}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  {/* Locked quantity display */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{
                      background: '#f3f4f6', borderRadius: 8, padding: '4px 12px',
                      fontSize: 14, fontWeight: 800, color: '#374151',
                      fontFamily: "'Playfair Display', serif",
                      border: '1px solid #e5e7eb',
                    }}>
                      x{item.qty}
                    </div>
                    <span style={{ fontSize: 11, color: '#9ca3af' }}>phần</span>
                  </div>
                  <span style={{ fontSize: 15, fontWeight: 700, color: '#b82c0a' }}>{fmt(item.dish.price * item.qty)}</span>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Bill summary */}
        <div style={{
          background: '#fff', borderRadius: 14, padding: '14px 16px',
          border: '1px solid rgba(200,160,80,0.15)',
          boxShadow: '0 2px 10px rgba(0,0,0,0.06)', marginTop: 6,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 13, color: '#7a5030' }}>Tạm tính ({orders.reduce((s,i) => s + i.qty, 0)} món)</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(subtotal)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, paddingBottom: 10, borderBottom: '1px dashed rgba(200,160,80,0.3)' }}>
            <span style={{ fontSize: 13, color: '#7a5030' }}>VAT (8%)</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(vat)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#1e0f04' }}>Tổng tiền tạm tính</span>
            <span style={{ fontSize: 17, fontWeight: 800, color: '#b82c0a', fontFamily: "'Playfair Display', serif" }}>{fmt(total)}</span>
          </div>
          <div style={{ fontSize: 11, color: '#a08060', marginTop: 6, textAlign: 'right' }}>(Đã bao gồm VAT 8%)</div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{
        position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100,
        background: '#fff', borderTop: '1px solid rgba(200,160,80,0.2)',
        boxShadow: '0 -4px 24px rgba(0,0,0,0.1)',
        padding: '14px 16px 28px',
      }}>
        <div style={{ maxWidth: 430, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <span style={{ fontSize: 13, color: '#7a5030' }}>Tổng tiền tạm tính:</span>
            <span style={{ fontSize: 19, fontWeight: 800, color: '#b82c0a', fontFamily: "'Playfair Display', serif" }}>{fmt(total)}</span>
          </div>
          <button
            onClick={onPayment}
            style={{
              width: '100%', padding: '16px',
              background: 'linear-gradient(135deg, #b8860b 0%, #d4a820 30%, #f0c040 60%, #d4a820 100%)',
              border: 'none', borderRadius: 14,
              fontSize: 16, fontWeight: 800,
              fontFamily: "'Be Vietnam Pro', sans-serif",
              color: '#1e0f04', cursor: 'pointer',
              letterSpacing: '0.1em',
              boxShadow: '0 6px 28px rgba(212,168,32,0.5)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
            </svg>
            THANH TOÁN
          </button>
        </div>
      </div>
    </div>
  )
}
