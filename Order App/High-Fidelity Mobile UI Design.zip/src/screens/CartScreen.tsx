import { useState } from 'react'
import type { CartItem, Dish } from '../types'
import { UPSELL_DISHES, fmt } from '../data'

// ─── Cart item row ────────────────────────────────────────────────────────────

function CartRow({
  item,
  onChange,
  onDelete,
}: {
  item: CartItem
  onChange: (qty: number) => void
  onDelete: () => void
}) {
  const [confirming, setConfirming] = useState(false)

  const handleMinus = () => {
    if (item.qty === 1) { setConfirming(true) } else { onChange(item.qty - 1) }
  }

  return (
    <div style={{
      background: '#fff',
      borderRadius: 14,
      marginBottom: 10,
      boxShadow: '0 2px 12px rgba(0,0,0,0.07)',
      border: '1px solid rgba(200,160,80,0.15)',
      overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', gap: 12, padding: '12px 12px 12px 12px', alignItems: 'flex-start' }}>
        {/* Photo */}
        <div style={{ width: 70, height: 70, borderRadius: 9, overflow: 'hidden', flexShrink: 0, background: '#4a2810' }}>
          <img src={item.dish.image} alt={item.dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
        </div>

        {/* Info */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: 14, color: '#1e0f04', lineHeight: 1.25, marginBottom: 5 }}>
            {item.dish.name}
          </div>
          {item.selectedModifiers.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginBottom: 7 }}>
              {item.selectedModifiers.map(m => (
                <span key={m} style={{
                  fontSize: 11, color: '#8a5c20',
                  background: '#fff8e8',
                  border: '1px solid #e8d5a0',
                  borderRadius: 10, padding: '2px 8px',
                  fontWeight: 500,
                }}>{m}</span>
              ))}
            </div>
          )}
          <div style={{ fontSize: 15, fontWeight: 700, color: '#b82c0a' }}>
            {fmt(item.dish.price * item.qty)}
          </div>
          {item.qty > 1 && (
            <div style={{ fontSize: 11, color: '#a08060', marginTop: 1 }}>
              {fmt(item.dish.price)} × {item.qty}
            </div>
          )}
        </div>

        {/* Delete */}
        <button onClick={() => { setConfirming(false); onDelete() }} style={{
          width: 28, height: 28, borderRadius: '50%',
          background: '#fff0f0', border: '1.5px solid #fca5a5',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', flexShrink: 0, marginTop: 2,
        }}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#e11d48" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      {/* Qty selector */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'flex-end',
        padding: '0 12px 12px', gap: 0,
      }}>
        {confirming ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 12, color: '#e11d48', fontWeight: 500 }}>Xoá khỏi giỏ?</span>
            <button onClick={onDelete} style={{
              padding: '4px 12px', borderRadius: 8,
              background: '#e11d48', border: 'none', color: '#fff',
              fontSize: 12, fontWeight: 700, cursor: 'pointer',
            }}>Xoá</button>
            <button onClick={() => setConfirming(false)} style={{
              padding: '4px 12px', borderRadius: 8,
              background: '#f5f5f5', border: 'none', color: '#555',
              fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}>Giữ lại</button>
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 0, border: '2px solid #e8d5a0', borderRadius: 10, overflow: 'hidden', background: '#fffbf0' }}>
            <button onClick={handleMinus} style={{
              width: 38, height: 36, border: 'none',
              background: 'linear-gradient(135deg, #f5e8b0, #f0c040)',
              cursor: 'pointer', fontSize: 20, color: '#1e0f04',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>−</button>
            <div style={{ width: 38, textAlign: 'center', fontSize: 16, fontWeight: 700, color: '#1e0f04', fontFamily: "'Playfair Display', serif" }}>
              {item.qty}
            </div>
            <button onClick={() => onChange(item.qty + 1)} style={{
              width: 38, height: 36, border: 'none',
              background: 'linear-gradient(135deg, #c9a227, #f0c040)',
              cursor: 'pointer', fontSize: 20, color: '#1e0f04',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>+</button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Upsell card ──────────────────────────────────────────────────────────────

function UpsellCard({ dish, onAdd }: { dish: Dish; onAdd: () => void }) {
  return (
    <div style={{
      minWidth: 130, flexShrink: 0,
      background: '#fff', borderRadius: 13,
      border: '1px solid rgba(200,160,80,0.18)',
      boxShadow: '0 2px 10px rgba(0,0,0,0.08)',
      overflow: 'hidden',
    }}>
      <div style={{ height: 88, background: '#4a2810', position: 'relative' }}>
        <img src={dish.image} alt={dish.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}/>
      </div>
      <div style={{ padding: '8px 9px 10px' }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 600, fontSize: 12, color: '#1e0f04', marginBottom: 3, lineHeight: 1.3, minHeight: 30 }}>
          {dish.name}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#b82c0a' }}>{fmt(dish.price)}</span>
          <button onClick={onAdd} style={{
            width: 26, height: 26, borderRadius: '50%',
            background: 'linear-gradient(135deg, #c9a227, #f0c040)',
            border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, color: '#1e0f04', fontWeight: 300,
            boxShadow: '0 2px 6px rgba(240,192,64,0.4)',
          }}>+</button>
        </div>
      </div>
    </div>
  )
}

// ─── Cart Screen ──────────────────────────────────────────────────────────────

interface Props {
  cart: CartItem[]
  onBack: () => void
  onChange: (id: number, qty: number) => void
  onDelete: (id: number) => void
  onAddUpsell: (dish: Dish) => void
  onOrder: () => void
}

export default function CartScreen({ cart, onBack, onChange, onDelete, onAddUpsell, onOrder }: Props) {
  const [ordering, setOrdering] = useState(false)

  const subtotal = cart.reduce((s, i) => s + i.dish.price * i.qty, 0)
  const vat = Math.round(subtotal * 0.08)
  const total = subtotal + vat

  const handleOrder = () => {
    setOrdering(true)
    setTimeout(() => { setOrdering(false); onOrder() }, 1100)
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f7f2ea', fontFamily: "'Be Vietnam Pro', sans-serif" }}>

      {/* Header */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 50,
        background: '#fff',
        borderBottom: '1px solid rgba(200,160,80,0.2)',
        boxShadow: '0 1px 12px rgba(0,0,0,0.07)',
        padding: '0 16px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', height: 56 }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '8px 8px 8px 0', display: 'flex', alignItems: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, fontSize: 18, color: '#1e0f04' }}>Giỏ hàng</div>
          </div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 5,
            background: 'rgba(200,130,30,0.1)', border: '1px solid rgba(200,130,30,0.35)',
            borderRadius: 16, padding: '3px 10px',
          }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="rgba(180,100,20,0.7)">
              <rect x="2" y="7" width="20" height="3" rx="1.5"/>
              <rect x="5" y="10" width="3" height="7" rx="1"/><rect x="16" y="10" width="3" height="7" rx="1"/>
            </svg>
            <span style={{ fontSize: 11.5, color: '#8a5010', fontWeight: 700, letterSpacing: '0.05em' }}>Bàn A1</span>
          </div>
        </div>
      </div>

      <div style={{ padding: '14px 16px', paddingBottom: 130 }}>

        {/* Empty state */}
        {cart.length === 0 ? (
          <div style={{ textAlign: 'center', paddingTop: 64 }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>🛒</div>
            <div style={{ fontSize: 16, fontWeight: 600, color: '#6b4020', marginBottom: 6 }}>Giỏ hàng trống</div>
            <div style={{ fontSize: 13, color: '#a08060' }}>Thêm món từ thực đơn để bắt đầu</div>
          </div>
        ) : (
          <>
            {/* Item count */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ width: 3, height: 14, borderRadius: 2, background: 'linear-gradient(180deg, #f0c040, #c9a227)' }}/>
              <span style={{ fontSize: 12, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                {cart.reduce((s,i) => s + i.qty, 0)} món đã chọn
              </span>
            </div>

            {/* Cart items */}
            {cart.map(item => (
              <CartRow
                key={item.dish.id}
                item={item}
                onChange={qty => onChange(item.dish.id, qty)}
                onDelete={() => onDelete(item.dish.id)}
              />
            ))}

            {/* Price breakdown */}
            <div style={{
              background: '#fff', borderRadius: 14, padding: '14px 16px',
              border: '1px solid rgba(200,160,80,0.15)',
              boxShadow: '0 2px 10px rgba(0,0,0,0.06)',
              marginBottom: 20, marginTop: 6,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <span style={{ fontSize: 13, color: '#7a5030' }}>Tạm tính</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(subtotal)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, paddingBottom: 10, borderBottom: '1px dashed rgba(200,160,80,0.3)' }}>
                <span style={{ fontSize: 13, color: '#7a5030' }}>VAT (8%)</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: '#1e0f04' }}>{fmt(vat)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#1e0f04' }}>Tổng tiền tạm tính</span>
                <span style={{ fontSize: 16, fontWeight: 800, color: '#b82c0a' }}>{fmt(total)}</span>
              </div>
            </div>
          </>
        )}

        {/* Upsell */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <div style={{ width: 3, height: 14, borderRadius: 2, background: 'linear-gradient(180deg, #f0c040, #c9a227)' }}/>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#8a5c20', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
              Có thể bạn quan tâm?
            </span>
          </div>
          <div className="hide-scrollbar" style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 4 }}>
            {UPSELL_DISHES.map(dish => (
              <UpsellCard key={dish.id} dish={dish} onAdd={() => onAddUpsell(dish)} />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom action bar */}
      {cart.length > 0 && (
        <div style={{
          position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 100,
          background: '#fff',
          borderTop: '1px solid rgba(200,160,80,0.2)',
          boxShadow: '0 -4px 24px rgba(0,0,0,0.1)',
          padding: '14px 16px 28px',
        }}>
          <div style={{ maxWidth: 430, margin: '0 auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
              <span style={{ fontSize: 13, color: '#7a5030' }}>Tổng tiền tạm tính:</span>
              <span style={{ fontSize: 18, fontWeight: 800, color: '#b82c0a', fontFamily: "'Playfair Display', serif" }}>{fmt(total)}</span>
            </div>
            <button
              onClick={handleOrder}
              disabled={ordering}
              style={{
                width: '100%', padding: '16px',
                background: ordering
                  ? 'rgba(212,168,32,0.6)'
                  : 'linear-gradient(135deg, #b8860b 0%, #d4a820 30%, #f0c040 60%, #d4a820 100%)',
                border: 'none', borderRadius: 14,
                fontSize: 16, fontWeight: 800,
                fontFamily: "'Be Vietnam Pro', sans-serif",
                color: '#1e0f04', cursor: ordering ? 'default' : 'pointer',
                letterSpacing: '0.1em',
                boxShadow: ordering ? 'none' : '0 6px 28px rgba(212,168,32,0.5)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                transition: 'all 0.15s',
              }}
            >
              {ordering ? (
                <>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" style={{ animation: 'spin 0.8s linear infinite' }}>
                    <path d="M12 2a10 10 0 1 0 10 10" />
                  </svg>
                  Đang gửi món...
                </>
              ) : (
                <>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1e0f04" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>
                  </svg>
                  GỌI MÓN
                </>
              )}
            </button>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
