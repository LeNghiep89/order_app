import { useState, useCallback } from 'react'
import type { Screen, CartItem, OrderItem, Dish } from './types'
import { ALL_DISHES } from './data'

import ScannerScreen from './screens/ScannerScreen'
import CheckinSheet from './screens/CheckinSheet'
import LoadingScreen from './screens/LoadingScreen'
import MenuScreen from './screens/MenuScreen'
import CartScreen from './screens/CartScreen'
import OrderScreen from './screens/OrderScreen'
import PaymentScreen from './screens/PaymentScreen'
import TabletCheckinScreen from './screens/TabletCheckinScreen'

// ─── Screen transition wrapper ────────────────────────────────────────────────

function SlideView({ screen, children }: { screen: Screen; children: React.ReactNode }) {
  return (
    <div key={screen} style={{
      position: 'absolute', inset: 0,
      animation: 'slideIn 0.3s cubic-bezier(0.4,0,0.2,1) both',
    }}>
      {children}
    </div>
  )
}

// ─── Demo nav bar (prototype only) ───────────────────────────────────────────

const FLOW: Screen[] = ['tablet-checkin', 'scanner', 'menu', 'cart', 'order', 'payment']
const LABELS: Partial<Record<Screen, string>> = {
  'tablet-checkin': '⊞ Tablet',
  scanner: 'Scan',
  menu: 'Thực đơn',
  cart: 'Giỏ hàng',
  order: 'Đã gọi',
  payment: 'Thanh toán',
}

function PrototypeNav({ current, onGo }: { current: Screen; onGo: (s: Screen) => void }) {
  return (
    <div style={{
      position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 9999,
      display: 'flex', justifyContent: 'center', pointerEvents: 'none',
    }}>
      <div style={{
        display: 'flex', gap: 4, padding: '6px 10px',
        background: 'rgba(30,15,4,0.88)', borderRadius: '20px 20px 0 0',
        backdropFilter: 'blur(12px)',
        boxShadow: '0 -2px 20px rgba(0,0,0,0.35)',
        pointerEvents: 'all',
      }}>
        {FLOW.map(s => (
          <button key={s} onClick={() => onGo(s)} style={{
            padding: '5px 12px', borderRadius: 14,
            background: current === s ? 'linear-gradient(135deg, #c9a227, #f0c040)' : 'rgba(240,192,64,0.1)',
            border: 'none', cursor: 'pointer',
            fontSize: 11.5, fontWeight: current === s ? 700 : 500,
            color: current === s ? '#1e0f04' : 'rgba(240,192,64,0.65)',
            fontFamily: "'Be Vietnam Pro', sans-serif",
            transition: 'all 0.15s',
          }}>
            {LABELS[s]}
          </button>
        ))}
      </div>
    </div>
  )
}

// ─── App root ─────────────────────────────────────────────────────────────────

// Pre-fill cart with sample data so Cart/Order screens are demo-ready
const DEMO_CART: CartItem[] = [
  { dish: ALL_DISHES[2], qty: 2, selectedModifiers: ['Không cay', 'Nước sốt thêm'] },
  { dish: ALL_DISHES[3], qty: 1, selectedModifiers: ['Ít cay'] },
  { dish: ALL_DISHES[7], qty: 1, selectedModifiers: ['Ít đá'] },
]

const DEMO_ORDERS: OrderItem[] = [
  { ...DEMO_CART[0], status: 'served' },
  { ...DEMO_CART[1], status: 'preparing' },
  { ...DEMO_CART[2], status: 'sent' },
  { dish: ALL_DISHES[5], qty: 1, selectedModifiers: ['Không cay'], status: 'preparing' },
]

export default function App() {
  const [screen, setScreen] = useState<Screen>('tablet-checkin')
  const [showCheckin, setShowCheckin] = useState(false)
  const [loading, setLoading] = useState(false)
  const [guests, setGuests] = useState(2)
  const [cart, setCart] = useState<CartItem[]>(DEMO_CART)
  const [orders, setOrders] = useState<OrderItem[]>(DEMO_ORDERS)
  const [submittedAt] = useState(new Date('2025-09-08T17:09:00'))

  const goTo = useCallback((s: Screen) => {
    setShowCheckin(false)
    setLoading(false)
    setScreen(s)
  }, [])

  const handleScanSuccess = useCallback(() => {
    setShowCheckin(true)
  }, [])

  const handleCheckin = useCallback((g: number) => {
    setGuests(g)
    setShowCheckin(false)
    setLoading(true)
  }, [])

  const handleLoadingDone = useCallback(() => {
    setLoading(false)
    setScreen('menu')
  }, [])

  const handleAddToCart = useCallback((item: CartItem) => {
    setCart(prev => {
      const idx = prev.findIndex(i => i.dish.id === item.dish.id && JSON.stringify(i.selectedModifiers) === JSON.stringify(item.selectedModifiers))
      if (idx >= 0) {
        const next = [...prev]
        next[idx] = { ...next[idx], qty: next[idx].qty + item.qty }
        return next
      }
      return [...prev, item]
    })
  }, [])

  const handleCartChange = useCallback((id: number, qty: number) => {
    setCart(prev => prev.map(i => i.dish.id === id ? { ...i, qty } : i).filter(i => i.qty > 0))
  }, [])

  const handleCartDelete = useCallback((id: number) => {
    setCart(prev => prev.filter(i => i.dish.id !== id))
  }, [])

  const handleAddUpsell = useCallback((dish: Dish) => {
    setCart(prev => {
      const idx = prev.findIndex(i => i.dish.id === dish.id)
      if (idx >= 0) {
        const next = [...prev]; next[idx] = { ...next[idx], qty: next[idx].qty + 1 }; return next
      }
      return [...prev, { dish, qty: 1, selectedModifiers: [] }]
    })
  }, [])

  const handleOrder = useCallback(() => {
    setOrders(cart.map(item => ({ ...item, status: 'sent' as const })))
    setCart([])
    setScreen('order')
  }, [cart])

  const isTablet = screen === 'tablet-checkin'

  return (
    <div style={{
      position: 'relative',
      maxWidth: isTablet ? '100%' : 430,
      margin: '0 auto',
      minHeight: '100vh',
      overflow: 'hidden',
      background: '#1e0f04',
    }}>
      <style>{`
        @keyframes slideIn {
          from { transform: translateX(32px); opacity: 0; }
          to   { transform: translateX(0);    opacity: 1; }
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>

      {/* Screen layer */}
      <div style={{ position: 'relative', minHeight: '100vh', paddingBottom: (screen !== 'scanner' && !isTablet) ? 50 : 0 }}>

        {screen === 'tablet-checkin' && (
          <TabletCheckinScreen onStart={(g, _note) => { setGuests(g); setLoading(true); setScreen('scanner') }} />
        )}

        {screen === 'scanner' && (
          <ScannerScreen onSuccess={handleScanSuccess} onManual={() => setShowCheckin(true)} />
        )}

        {screen === 'menu' && (
          <SlideView screen="menu">
            <MenuScreen
              cart={cart}
              onAddToCart={handleAddToCart}
              onViewCart={() => setScreen('cart')}
              guests={guests}
            />
          </SlideView>
        )}

        {screen === 'cart' && (
          <SlideView screen="cart">
            <CartScreen
              cart={cart}
              onBack={() => setScreen('menu')}
              onChange={handleCartChange}
              onDelete={handleCartDelete}
              onAddUpsell={handleAddUpsell}
              onOrder={handleOrder}
            />
          </SlideView>
        )}

        {screen === 'order' && (
          <SlideView screen="order">
            <OrderScreen
              orders={orders}
              onPayment={() => setScreen('payment')}
              onBack={() => setScreen('menu')}
              submittedAt={submittedAt}
            />
          </SlideView>
        )}

        {screen === 'payment' && (
          <SlideView screen="payment">
            <PaymentScreen
              orders={orders}
              onBack={() => setScreen('order')}
            />
          </SlideView>
        )}

        {/* Overlays */}
        {showCheckin && (
          <CheckinSheet onStart={(g, _note) => handleCheckin(g)} />
        )}

        {loading && (
          <LoadingScreen onDone={handleLoadingDone} />
        )}
      </div>

      {/* Prototype nav (always on top) */}
      <PrototypeNav current={screen} onGo={goTo} />
    </div>
  )
}
